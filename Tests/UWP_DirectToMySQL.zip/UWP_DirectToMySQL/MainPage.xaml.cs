﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// Die Vorlage "Leere Seite" ist unter http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 dokumentiert.

namespace UWP_DirectToMySQL
{
    /// <summary>
    /// Eine leere Seite, die eigenständig verwendet oder zu der innerhalb eines Rahmens navigiert werden kann.
    /// </summary>
    public sealed partial class MainPage : Page
    {
       
        //protected override void OnNavigatedTo(NavigationEventArgs e)
        //{
        //    using (var connection = new MySqlConnection
        //    {
        //        ConnectionString = "server=K-Chan-PC;user id=Cristian;password=EstaEsMiPass123;persistsecurityinfo=True;port=3305;database=test_datenbank"
        //    })

        //    {
        //        connection.Open();
        //        var command = new MySqlCommand("SELECT * FROM test_directuwp.benutzers;", connection);

        //        //using (MySqlDataReader reader = command.ExecuteReader())
        //        //{
        //        //    while (reader.Read())
        //        //    {
        //        //        Console.WriteLine($"{reader["category_id"]}: {reader["name"]} {reader["last_update"]}");

        //        //    }
        //        //}  
        //    }
        //}

        public MainPage()
        {
            this.InitializeComponent();
        }

        private void InsertTodoBtn_Click(object sender, RoutedEventArgs e)
        {
            // Try the the View Model insertion and check externally for result
            App.TODO_VIEW_MODEL.InsertNewTodo(NewTodoTxtBox.Text);
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            Todos.ItemsSource = App.TODO_VIEW_MODEL.GetTodos();
        }

        private void DeleteTodoBtn_Click(object sender, RoutedEventArgs e)
        {
        //    App.TODO_VIEW_MODEL.DeleteEinTodo();
        }
    }
}
