﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UWP_DirectToMySQL.Klassen;

namespace UWP_DirectToMySQL.Model
{
    public class TodoViewModel
    {
        private static TodoViewModel _todoViewModel = new TodoViewModel();
        private ObservableCollection<Todo> _allToDos = new ObservableCollection<Todo>();

        public ObservableCollection<Todo> AllTodos
        {
            get
            {
                return _todoViewModel._allToDos;
            }
        }



        public IEnumerable<Todo> GetTodos()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection("server=RFHINF528;user id=MyUser;password=1234;persistsecurityinfo=True;port=3306;database=test_directuwp;SslMode=None"))
                {
                    connection.Open();
                    MySqlCommand getCommand = connection.CreateCommand();
                    getCommand.CommandText = "SELECT whatToDo FROM test_directuwp.todo";                
                    using (MySqlDataReader reader = getCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            _todoViewModel._allToDos.Add(new Todo(reader.GetString("whatToDo")));
                        }
                    }
                }
            }
           catch (MySqlException)
            {
                // Handle it 
              //  Message
           }
            return _todoViewModel.AllTodos;
        }
        

    
        public bool InsertNewTodo(string what)
        {
            Todo newTodo = new Todo(what);
            // Insert to the collection and update DB
            try
            {
                using (MySqlConnection connection = new MySqlConnection("server=RFHINF528;user id=MyUser;password=1234;persistsecurityinfo=True;port=3306;database=test_directuwp;SslMode=None"))
                {
                    connection.Open();
                    MySqlCommand insertCommand = connection.CreateCommand();
                    insertCommand.CommandText = "INSERT INTO todo(whatToDo)VALUES(@whatToDo)";
                    insertCommand.Parameters.AddWithValue("@whatToDo", newTodo.whatToDo);
                    insertCommand.ExecuteNonQuery();
                    _todoViewModel._allToDos.Add(newTodo);
                    return true;
                }
            }
            catch (MySqlException )
            {
                // Don't forget to handle it
                return false;
            }
        }
       
        //public bool DeleteEinTodo(int id)
        //{
        //    //getCommand.CommandText = "DELETE FROM todo WHERE idtodo= id";
        //    using (MySqlConnection connection = new MySqlConnection("server=RFHINF528;user id=MyUser;password=1234;persistsecurityinfo=True;port=3306;database=test_directuwp;SslMode=None"))
        //    {
        //        connection.Open();
        //        MySqlCommand deleteCommand = connection.CreateCommand();
        //        deleteCommand.CommandText = "DELETE FROM todo WHERE idtodo=" + id;
        //        using (MySqlDataReader reader = deleteCommand.ExecuteReader())
        //        {
                    
        //            _todoViewModel._allToDos.Add(new Todo(reader.GetString("whatToDo")));
                  
        //        }

        //        return true;
        //    }
        //}

        public TodoViewModel()
        { }
    }

}
