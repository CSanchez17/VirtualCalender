﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UWP_DirectToMySQL.Klassen
{
    public class Todo
    {
        public string whatToDo { get; set; }
        public Todo(string what)
        {
            whatToDo = what;
        }
    }
}
